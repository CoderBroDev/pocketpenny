Hello!

If you are here, You've found the ~~secret~~ read me page!

This python file is everything that pocketdimension runs on, please dont break anything, also, if you want to know my token.. its.. Waitaminute.. stop tryna make me tell you how to break this.

Anyways

Pocket dimension is like a ripoff unbelievaboat, except made by one person!


We have
- Farming!
- Mini-Economy
- ~~Working 2 hours just to get 1 dollar~~ A balanced income system

